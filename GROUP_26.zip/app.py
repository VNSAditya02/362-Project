import os
import psycopg2
from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime
import time
import json

app = Flask(__name__, template_folder='FRONT_END/templates', static_folder='FRONT_END/static')

@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return response

def get_db_connection():
    conn = psycopg2.connect(
        host = "10.17.5.97",
        database = "group_26",
        user = "group_26",
        password = "dV9AdHyGN2hk2",
        port = "5432"
    )
    return conn

@app.route('/')
def login():
    return render_template("home_temp.html")

@app.route('/signin/<prompt>', methods = ['GET'])
def take(prompt):
    return render_template("login.html", prompt = prompt)

@app.route('/signup/<prompt>', methods = ['GET'])
def signup(prompt):
    return render_template("signup.html", prompt = prompt)

@app.route('/<userName>', methods = ['GET'])
def homepage(userName):
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT quizId FROM userQuizStats WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND quizMarks IS NULL ORDER BY quizId;" .format('$$' + userName + '$$'))
    pendingQuizIds = cur.fetchall()

    cur.execute("SELECT * FROM categories ORDER BY categoryName;")
    categories = cur.fetchall()

    return render_template("home.html", userName = userName, pendingQuizIds = pendingQuizIds, categories = categories)

@app.route('/home', methods = ['POST'])
def home():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT userName FROM users WHERE userName = {} AND password = {};" .format('$$' + request.form["Username"] + '$$', '$$' + request.form["Password"] + '$$'))
    out = cur.fetchall()
    if(len(out) == 0):
        return redirect('/signin/Invalid Username or Password')
    return redirect('/' + str(request.form["Username"]))

@app.route('/addUser', methods = ['POST'])
def addUser():
    userName = '$$' + request.form["Username"] + '$$'
    password = '$$' + request.form["Password"] + '$$'
    institute = '$$' + request.form["Institute"] + '$$'
    country = '$$' + request.form["Country"] + '$$'

    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM users WHERE userName = {};" .format(userName))
    l = cur.fetchall()
    if (len(l) != 0):
        return redirect('/signup/username already exists')
    if (request.form["Password"] != request.form["RePassword"]):
        return redirect('/signup/Invalid: Reconfirm Password')

    cur.execute("SELECT max(userId) FROM users;")
    userId = cur.fetchall()[0][0] + 1
    cur.execute("INSERT INTO users (userId,userName,password,country,institute,userRating,userNumQuiz) VALUES ({}, {}, {}, {}, {}, 0, 0);" .format(userId, userName, password, country, institute))
    conn.commit()
    return redirect('/')

@app.route('/<userName>/<quizId>/attemp_quiz', methods = ['GET'])
def quiz(userName, quizId):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if Quiz is already attempted or user has access
    cur.execute("SELECT quizMarks FROM userQuizStats WHERE quizId = {} AND userId = (SELECT userId FROM users WHERE userName = {})" .format(quizId, '$$' + userName + '$$'))
    l = cur.fetchall()
    if(len(l) == 0):
        return redirect('/' + userName)

    if(l[0][0] != None):
        return redirect('/' + str(userName) + '/' + userName + '/' + str(quizId) + '/results')

    # Get the start time of the Quiz
    cur.execute("SELECT startTime FROM userQuizStats WHERE quizId = {};" .format(quizId))
    startTime = cur.fetchall()[0][0]

    # Render Quiz
    cur.execute("SELECT * FROM questions WHERE questionId IN (SELECT questionId FROM quizzes WHERE quizId = {}) ORDER BY questionId;" .format(quizId))
    questions = cur.fetchall()
    return render_template("questions.html", userName = userName, questions = questions, quizId = quizId, startTime = json.dumps(time.mktime(startTime.timetuple())*1000))

@app.route('/<userName>/questions', methods = ['POST'])
def questions(userName):
    conn = get_db_connection()
    cur = conn.cursor()

    # Finding UserId
    cur.execute("SELECT userId FROM users WHERE userName = {};" .format('$$' + str(userName) + '$$'))
    userId = cur.fetchall()[0][0]

    categoryId = request.form["categories"]

    # Selecting 10 Random Questions
    cur.execute("SELECT * FROM questions, categories WHERE questions.categoryId = categories.categoryId AND categories.categoryId = {} ORDER BY RANDOM() limit 10;" .format(categoryId))
    questions = cur.fetchall()

    # Selecting QuizId
    cur.execute("SELECT max(quizId) FROM userQuizStats")
    quizId = cur.fetchall()[0][0] + 1

    # Selecting start time
    startTime = datetime.now()

    # Updating userQuizStats
    cur.execute("INSERT INTO userQuizStats (quizId,userId,quizMarks,startTime) VALUES ({}, {}, NULL,'{}');" .format(quizId, userId, startTime.strftime('%Y-%m-%d %H:%M:%S')))

    # Updating Quizzes
    for question in questions:
        cur.execute("INSERT INTO quizzes (quizId,questionId,chosenOption,correctOption) VALUES ({}, {}, NULL, {});" .format(quizId, question[0], '$$' + str(question[3]) + '$$'))
    
    conn.commit()
    return redirect('/' + str(userName) + '/' + str(quizId) + '/attemp_quiz')

@app.route('/<userName>/<otherName>/<quizId>/results', methods = ['GET'])
def display_results(userName, otherName, quizId):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT quizMarks FROM userQuizStats WHERE quizId = {} AND userId = (SELECT userId FROM users WHERE userName = {})" .format(quizId, '$$' + otherName + '$$'))
    marks = cur.fetchall()

    # Check if user has access/ User has completed attempt
    if(len(marks) == 0):
        return redirect('/' + userName+'/'+otherName+'/profile_quizzes')

    if(marks[0][0] == None):
        if(userName == otherName):
            return redirect('/' + userName+'/'+quizId+'/attemp_quiz')
        return redirect('/' + userName+'/'+otherName+'/profile_quizzes')

    # Render results
    cur.execute("SELECT question, chosenOption, correctOption FROM questions, quizzes WHERE questions.questionId = quizzes.questionId AND questions.questionId IN (SELECT questionId FROM quizzes WHERE quizId = {}) AND quizzes.quizId = {} ORDER BY questions.questionId;" .format(quizId, quizId))
    questions = cur.fetchall()
    return render_template("results.html", userName = userName, otherName = otherName, questions = questions, quizMarks = marks[0][0])

@app.route('/<quizId>/results', methods = ['POST'])
def results(quizId):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT userName FROM users WHERE userId = (SELECT userId FROM userQuizStats WHERE quizId = {});" .format(quizId))
    userName = cur.fetchall()[0][0]

    # Select the required Quiz
    cur.execute("SELECT * FROM quizzes WHERE quizId = {};" .format(quizId))
    rows = cur.fetchall()

    # Update Answers
    for row in rows:
        if(str(row[1]) not in request.form):
            cur.execute("UPDATE quizzes SET chosenOption = 'NONE' WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option1"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option1 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option2"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option2 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option3"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option3 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option4"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option4 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))

    # Update Quiz Marks
    cur.execute("UPDATE userQuizStats SET quizMarks = (SELECT count(*) FROM quizzes WHERE quizId = {} AND chosenOption = correctOption) WHERE quizId = {};" .format(quizId, quizId))
    cur.execute("UPDATE users SET userNumQuiz = 1 + (SELECT userNumQuiz FROM users WHERE userName = {}) WHERE userName = {};" .format('$$' + userName + '$$', '$$' + userName + '$$'))
    cur.execute("UPDATE users SET userRating = (SELECT userRating FROM users WHERE userName = {}) + (SELECT quizMarks FROM userQuizStats WHERE quizId = {}) WHERE userName = {};" .format('$$' + userName + '$$', quizId, '$$' + userName + '$$'))

    conn.commit()

    return redirect('/' + str(userName) + '/' + userName + '/' + str(quizId) + '/results')

@app.route('/<quizId>/timeout', methods = ['GET'])
def timeout(quizId):
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT userName FROM users WHERE userId = (SELECT userId FROM userQuizStats WHERE quizId = {});" .format(quizId))
    userName = cur.fetchall()[0][0]

    # Select the required Quiz
    cur.execute("SELECT * FROM quizzes WHERE quizId = {};" .format(quizId))
    rows = cur.fetchall()

    # Update Answers
    for row in rows:
        if(str(row[1]) not in request.form):
            cur.execute("UPDATE quizzes SET chosenOption = 'NONE' WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option1"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option1 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option2"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option2 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option3"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option3 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))
        elif(request.form[str(row[1])] == "option4"):
            cur.execute("UPDATE quizzes SET chosenOption = (SELECT option4 FROM questions WHERE questionId = {}) WHERE quizId = {} AND questionId = {};" .format(row[1], quizId, row[1]))

    # Update Quiz Marks
    cur.execute("UPDATE userQuizStats SET quizMarks = (SELECT count(*) FROM quizzes WHERE quizId = {} AND chosenOption = correctOption) WHERE quizId = {};" .format(quizId, quizId))
    cur.execute("UPDATE users SET userNumQuiz = 1 + (SELECT userNumQuiz FROM users WHERE userName = {}) WHERE userName = {};" .format('$$' + userName + '$$', '$$' + userName + '$$'))
    cur.execute("UPDATE users SET userRating = (SELECT userRating FROM users WHERE userName = {}) + (SELECT quizMarks FROM userQuizStats WHERE quizId = {}) WHERE userName = {};" .format('$$' + userName + '$$', quizId, '$$' + userName + '$$'))

    conn.commit()
    otherName = userName
    cur.execute("SELECT quizMarks FROM userQuizStats WHERE quizId = {} AND userId = (SELECT userId FROM users WHERE userName = {})" .format(quizId, '$$' + otherName + '$$'))
    marks = cur.fetchall()


    # Check if user has access/ User has completed attempt
    # if(len(marks) == 0):
    #     return redirect('/' + userName+'/'+otherName+'/profile_quizzes')

    # if(marks[0][0] == None):
    #     if(userName == otherName):
    #         return redirect('/' + userName+'/'+quizId+'/attemp_quiz')
    #     return redirect('/' + userName+'/'+otherName+'/profile_quizzes')

    # Render results
    cur.execute("SELECT question, chosenOption, correctOption FROM questions, quizzes WHERE questions.questionId = quizzes.questionId AND questions.questionId IN (SELECT questionId FROM quizzes WHERE quizId = {}) AND quizzes.quizId = {};" .format(quizId, quizId))
    questions = cur.fetchall()
    return render_template("results.html", userName = userName, otherName = otherName, questions = questions, quizMarks = marks[0][0])


@app.route('/<userName>/<otherName>/profile_details', methods = ['GET'])
def profile_details(userName, otherName):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if user exists. If not go to signin page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + userName + '$$'))
    l = cur.fetchall()
    if len(l) == 0:
        return redirect('/')

    # Check if other user exists. If not go to user home page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + otherName + '$$'))
    userData = cur.fetchall()
    if len(userData) == 0:
        return redirect('/'+userName)

    # Check if user and other user are friends
    cur.execute("SELECT * FROM friends WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND friendId = (SELECT userId FROM users WHERE userName = {})" .format('$$' + userName + '$$', '$$' + otherName + '$$'))
    friends = cur.fetchall()
    areFriends = "True"
    if(len(friends) == 0 and userName != otherName):
        areFriends = "False"
    page = "profile_details"
    return render_template("profile_details.html", userName = userName, otherName = otherName, userData = userData, areFriends = areFriends, page = page)

@app.route('/<userName>/<otherName>/profile_quizzes', methods = ['GET'])
def profile_quizzes(userName, otherName):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if user exists. If not go to signin page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + userName + '$$'))
    l = cur.fetchall()
    if len(l) == 0:
        return redirect('/')

    # Check if other user exists. If not go to user home page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + otherName + '$$'))
    userData = cur.fetchall()
    if len(userData) == 0:
        return redirect('/'+userName)

    cur.execute("SELECT quizId FROM userQuizStats WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND quizMarks IS NOT NULL ORDER BY quizId;" .format('$$' + otherName + '$$'))
    completedQuizIds = cur.fetchall()
    cur.execute("SELECT quizId FROM userQuizStats WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND quizMarks IS NULL ORDER BY quizId;" .format('$$' + otherName + '$$'))
    pendingQuizIds = cur.fetchall()

    # Check if user and other user are friends
    cur.execute("SELECT * FROM friends WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND friendId = (SELECT userId FROM users WHERE userName = {})" .format('$$' + userName + '$$', '$$' + otherName + '$$'))
    friends = cur.fetchall()
    areFriends = "True"
    if(len(friends) == 0 and userName != otherName):
        areFriends = "False"
    page = "profile_quizzes"
    return render_template("profile_quizzes.html", userName = userName, otherName = otherName, completedQuizIds = completedQuizIds, pendingQuizIds = pendingQuizIds, areFriends = areFriends, page = page)

@app.route('/<userName>/<otherName>/profile_following', methods = ['GET'])
def profile_following(userName, otherName):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if user exists. If not go to signin page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + userName + '$$'))
    l = cur.fetchall()
    if len(l) == 0:
        return redirect('/')

    # Check if other user exists. If not go to user home page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + otherName + '$$'))
    userData = cur.fetchall()
    if len(userData) == 0:
        return redirect('/'+userName)

    cur.execute("SELECT userName FROM users WHERE userId IN (SELECT friends.friendId FROM friends, users WHERE friends.userId = users.userId AND userName = {});" .format('$$' + otherName + '$$'))
    following = cur.fetchall()

    # Check if user and other user are friends
    cur.execute("SELECT * FROM friends WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND friendId = (SELECT userId FROM users WHERE userName = {})" .format('$$' + userName + '$$', '$$' + otherName + '$$'))
    friends = cur.fetchall()
    areFriends = "True"
    if(len(friends) == 0 and userName != otherName):
        areFriends = "False"
    page = "profile_following"
    return render_template("profile_following.html", userName = userName, otherName = otherName, following = following, areFriends = areFriends, page = page)

@app.route('/<userName>/<otherName>/profile_followers', methods = ['GET'])
def profile_followers(userName, otherName):
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if user exists. If not go to signin page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + userName + '$$'))
    l = cur.fetchall()
    if len(l) == 0:
        return redirect('/')

    # Check if other user exists. If not go to user home page
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + otherName + '$$'))
    userData = cur.fetchall()
    if len(userData) == 0:
        return redirect('/'+userName)

    cur.execute("SELECT userName FROM users WHERE userId IN (SELECT friends.userId FROM friends, users WHERE friends.friendId = users.userId AND userName = {});" .format('$$' + otherName + '$$'))
    followers = cur.fetchall()

    # Check if user and other user are friends
    cur.execute("SELECT * FROM friends WHERE userId = (SELECT userId FROM users WHERE userName = {}) AND friendId = (SELECT userId FROM users WHERE userName = {})" .format('$$' + userName + '$$', '$$' + otherName + '$$'))
    friends = cur.fetchall()
    areFriends = "True"
    if(len(friends) == 0 and userName != otherName):
        areFriends = "False"
    page = "profile_followers"
    return render_template("profile_followers.html", userName = userName, otherName = otherName, followers = followers, areFriends = areFriends, page = page)

@app.route('/<userName>/search_profile', methods = ['POST'])
def search_profile(userName):
    otherName = request.form["otherUser"]
    return redirect('/'+userName+'/'+otherName+'/profile_details')

@app.route('/<userName>/<otherName>/<page>/add_friend', methods = ['get'])
def add_friend(userName, otherName, page):
    print(page)
    conn = get_db_connection()
    cur = conn.cursor()

    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + userName + '$$'))
    l = cur.fetchall()
    if len(l) == 0:
        return redirect('/')
    cur.execute("SELECT * FROM users WHERE userName = {};" .format('$$' + otherName + '$$'))
    r = cur.fetchall()
    if len(r) == 0 or l[0][0] == r[0][0]:
        return redirect('/'+userName+'/profile')

    userId = l[0][0]
    friendId = r[0][0]
    cur.execute("INSERT INTO friends (userId, friendId) SELECT * FROM (SELECT {}, {}) AS tmp WHERE NOT EXISTS (SELECT * FROM friends WHERE userId = {} AND friendId = {}) LIMIT 1;" .format(userId, friendId, userId, friendId))
    conn.commit()
    return redirect('/'+userName+'/'+otherName+'/'+page)

@app.route('/<userName>/signout', methods = ['GET'])
def signout(userName):
    return redirect('/')
